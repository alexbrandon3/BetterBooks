import { AppDataSource } from "../data-source";
import { RecurringTransaction } from "../entities/RecurringTransaction";
import { Transaction } from "../entities/Transaction";
import { SplitTransaction } from "../entities/SplitTransaction";
import { Account } from "../entities/Account";
import { LessThanOrEqual } from "typeorm";

const recurringRepo = AppDataSource.getRepository(RecurringTransaction);
const transactionRepo = AppDataSource.getRepository(Transaction);
const splitRepo = AppDataSource.getRepository(SplitTransaction);
const accountRepo = AppDataSource.getRepository(Account);

const calculateNextRun = (
  current: Date,
  interval: number,
  recurrence: string
): Date => {
  const next = new Date(current);
  switch (recurrence) {
    case "DAILY":
      next.setDate(next.getDate() + interval);
      break;
    case "WEEKLY":
      next.setDate(next.getDate() + interval * 7);
      break;
    case "MONTHLY":
      next.setMonth(next.getMonth() + interval);
      break;
    case "YEARLY":
      next.setFullYear(next.getFullYear() + interval);
      break;
    default:
      throw new Error(`Unsupported recurrence: ${recurrence}`);
  }
  return next;
};

export const processRecurringTransactions = async () => {
  const now = new Date();

  const dueRecurring = await recurringRepo.find({
    where: {
      isActive: true,
      nextRun: LessThanOrEqual(now),
    },
    relations: ["user"],
  });

  for (const recurring of dueRecurring) {
    const transaction = transactionRepo.create({
      description: recurring.description!,
      type: recurring.type!,
      date: now,
      amount: recurring.amount!,
      user: recurring.user,
      recurringTransaction: recurring,
    });

    if (recurring.accountId) {
      const account = await accountRepo.findOneBy({ id: recurring.accountId });
      if (account) transaction.account = account;
    }

    const savedTransaction = await transactionRepo.save(transaction);

    // Update nextRun
    recurring.nextRun = calculateNextRun(
      recurring.nextRun!,
      recurring.interval!,
      recurring.recurrence!
    );
    await recurringRepo.save(recurring);
  }

  if (dueRecurring.length > 0) {
    console.log(`✅ Processed ${dueRecurring.length} recurring transaction(s)`);
  }
};

// Start interval scheduler
setInterval(() => {
  processRecurringTransactions().catch(console.error);
}, 60_000); // every 60 seconds
